def min_cost_path(cost_mat, M, N):
    rows = len(cost_mat)
    cols = len(cost_mat[0])

    dp = [[0] * cols for _ in range(rows)]

    dp[0][0] = cost_mat[0][0]
    for i in range(1, rows):
        dp[i][0] = dp[i - 1][0] + cost_mat[i][0]
    for j in range(1, cols):
        dp[0][j] = dp[0][j - 1] + cost_mat[0][j]

    for i in range(1, rows):
        for j in range(1, cols):
            dp[i][j] = cost_mat[i][j] + min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])

    return dp[M][N]