def frac_knapsack(items, capacity):

    ratio = [(item[0] / item[1], item) for item in items]
    
    sorted_items = sorted(ratio, key=lambda x: x[0], reverse=True)
    
    total = 0
    knapsack = []

    for ratio, item in sorted_items:
        if capacity >= item[1]:
            total += item[0]
            knapsack.append(item)
            capacity -= item[1]
        else:
            fraction = capacity / item[1]
            total += fraction * item[0]
            knapsack.append((item[0] * fraction, item[1] * fraction))
            break

    return total, knapsack