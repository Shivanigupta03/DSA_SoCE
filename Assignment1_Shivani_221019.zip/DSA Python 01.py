print("Please enter \n" "1 for Red \n" "2 for White \n" "1 for Blue \n")

l = list(input("Enter the Sequence of the balls: "))
print("Input: ", l)

n_red = l.count('1')
n_white = l.count('2')
n_blue = l.count('3')

for k in range (0,n_red):
    l[k] = '1'
for k in range (0,n_white):
    l[n_red+k] = '2'
for k in range (0,n_blue):
    l[n_red+n_white+k] = '3'
    
print("Output: ", l)

