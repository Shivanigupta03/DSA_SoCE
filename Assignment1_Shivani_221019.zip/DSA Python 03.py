class Array:
    def __init__(self):
        self.queue = []

    def insert(self, element):
        self.queue.append(element)

    def delete(self):
        if not self.isEmpty():
            return self.queue.pop(0)
        else:
            print("Queue is empty. Cannot delete.")
            return None

    def front(self):
        if not self.isEmpty():
            return self.queue[0]
        else:
            print("Queue is empty. No front element.")
            return None

    def rear(self):
        if not self.isEmpty():
            return self.queue[-1]
        else:
            print("Queue is empty. No rear element.")
            return None

    def isEmpty(self):
        return len(self.queue) == 0

    def size(self):
        return len(self.queue)