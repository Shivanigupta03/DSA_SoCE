from collections import Counter

def fre(arr):
    if len(set(arr)) < 3:
        print("NOT POSSIBLE")
        return

    counter = Counter(arr)
    stack = []
    queue = []

    for n, f in counter.items():
        while stack and stack[-1][1] < f:
            stack.pop()
        stack.append((n, f))

    for n, f in stack:
        queue.append((n, f))

    res = []
    for _ in range(3):
        if not queue:
            break
        res.append(queue.pop(0)[0])

    print(res)

arr = [7, 10, 11, 5, 2, 5, 5, 7, 11, 8, 9]
fre(arr)