from collections import deque

def Max(arr, k):
    result = []
    max_deque = deque()

    for i in range(len(arr)):
        # Remove elements that are out of the current window
        while max_deque and max_deque[0] < i - k + 1:
            max_deque.popleft()

        # Remove smaller elements from the back of the deque
        while max_deque and arr[max_deque[-1]] < arr[i]:
            max_deque.pop()

        max_deque.append(i)

        # Add maximum element for the current window to the result
        if i >= k - 1:
            result.append(arr[max_deque[0]])

    return result

# Example usage:
arr = [8, 5, 10, 7, 9, 4, 15, 12, 90, 13]
k = 4
output = Max(arr, k)
print("Output:", output)