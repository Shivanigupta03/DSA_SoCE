def min_max_height(build, k):
    l = 1
    r = max(build)

    while l < r:
        m = (l + r) // 2

        if can_min(build, k, m):
            r = m
        else:
            l = m + 1

    return l - 1

def can_min(build, k, target):
    for height in build:
        if height > target:
            k -= height - target
            if k < 0:
                return False
    return True