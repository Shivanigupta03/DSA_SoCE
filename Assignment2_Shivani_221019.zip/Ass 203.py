def Peak(num):
    l  = 0
    r = len(num) - 1

    while l < r:
        m = (l + r) // 2

        if num[m] > num[m + 1]:
            r = m
        else:
            l = m + 1

    return l