def Sort(array, target):
    res = []
    l = 0
    r = len(array) - 1

    while l < r:
        sum = array[l] + array[r]

        if sum == target:
            res.append([l, r])
            l += 1
            r -= 1
        elif sum < target:
            l += 1
        else:
            r -= 1

    return res