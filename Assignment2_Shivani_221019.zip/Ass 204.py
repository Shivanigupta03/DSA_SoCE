def search_descending(num, target):
    l = 0 
    r = len(num) - 1

    while l <= r:
        m = (l + r) // 2

        if num[m] == target:
            return m
        elif num[m] < target:
            r = m - 1
        else:
            l = m + 1

    return -1