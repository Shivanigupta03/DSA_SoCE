def Matrix(mat, target):
    if not mat or not mat[0]:
        return False

    r = len(mat)
    c = len(mat[0])
    l = 0 
    h = (r * c) - 1

    while l <= h:
        m = (l + h) // 2
        m_val = mat[m // c][m % c]

        if m_val == target:
            return True
        elif m_val < target:
            l = m + 1
        else:
            h = m - 1

    return False